$( document ).ready(function() {
  jcf.replaceAll();
});